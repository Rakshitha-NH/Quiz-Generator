import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const InputSchema = z.object({
  text: z.string().min(40, "Document is too short to generate questions from."),
  count: z.number().int().min(1).max(15),
  difficulty: z.enum(["easy", "medium", "hard"]),
  sourceName: z.string().optional(),
});

export type MCQ = {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
};

const SYSTEM = `You are an assessment designer. From the supplied document, write high-quality multiple-choice questions that test comprehension of the document's actual content.
Rules:
- Exactly 4 options per question, only one unambiguously correct.
- Distractors must be plausible and drawn from the document's domain.
- Never reference "the document" in the question text.
- Return STRICT JSON only: {"questions":[{"question":string,"options":[string,string,string,string],"correctIndex":0-3,"explanation":string}]}`;

export const generateQuiz = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => InputSchema.parse(input))
  .handler(async ({ data }) => {
    const key = process.env["LOVABLE_API_KEY"];
    if (!key) throw new Error("AI is not configured for this project.");

    const body = {
      model: "google/gemini-3.7-flash",
      messages: [
        { role: "system", content: SYSTEM },
        {
          role: "user",
          content: `Difficulty: ${data.difficulty}. Generate exactly ${data.count} MCQs.\n\nDocument${
            data.sourceName ? ` (${data.sourceName})` : ""
          }:\n"""\n${data.text.slice(0, 60000)}\n"""`,
        },
      ],
      response_format: { type: "json_object" },
    };

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Lovable-API-Key": key },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      const detail = await res.text();
      if (res.status === 429) throw new Error("Rate limited by the AI service. Try again shortly.");
      if (res.status === 402)
        throw new Error("AI credits exhausted. Add credits in Lovable to keep generating quizzes.");
      throw new Error(`Quiz generation failed (${res.status}): ${detail.slice(0, 300)}`);
    }

    const json = (await res.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const content = json.choices?.[0]?.message?.content ?? "";

    let parsed: unknown;
    try {
      parsed = JSON.parse(content);
    } catch {
      const match = content.match(/\{[\s\S]*\}/);
      if (!match) throw new Error("The AI returned an unreadable response. Please retry.");
      parsed = JSON.parse(match[0]);
    }

    const Out = z.object({
      questions: z
        .array(
          z.object({
            question: z.string(),
            options: z.array(z.string()).min(2),
            correctIndex: z.number().int().min(0),
            explanation: z.string().default(""),
          }),
        )
        .min(1),
    });

    const result = Out.parse(parsed);
    const questions: MCQ[] = result.questions.map((q) => ({
      ...q,
      correctIndex: Math.min(q.correctIndex, q.options.length - 1),
    }));

    return { questions, generatedAt: new Date().toISOString() };
  });
