import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation } from "@tanstack/react-query";
import { useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import {
  Brain,
  CheckCircle2,
  FileText,
  Loader2,
  RefreshCw,
  Sparkles,
  Target,
  Upload,
  XCircle,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Slider } from "@/components/ui/slider";
import { Toaster } from "@/components/ui/sonner";
import { generateQuiz, type MCQ } from "@/lib/quiz.functions";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "QuizForge — AI MCQ Generator from Documents" },
      {
        name: "description",
        content:
          "Upload a document and instantly generate multiple-choice questions with options, correct answers and explanations for candidate assessments.",
      },
      { property: "og:title", content: "QuizForge — AI MCQ Generator from Documents" },
      {
        property: "og:description",
        content:
          "Turn any study or job document into ready-to-use MCQ assessments in seconds, complete with answer keys.",
      },
    ],
  }),
  component: Dashboard,
});

const DIFFICULTIES = ["easy", "medium", "hard"] as const;
type Difficulty = (typeof DIFFICULTIES)[number];

function Dashboard() {
  const [text, setText] = useState("");
  const [sourceName, setSourceName] = useState<string>("");
  const [count, setCount] = useState(5);
  const [difficulty, setDifficulty] = useState<Difficulty>("medium");
  const [questions, setQuestions] = useState<MCQ[]>([]);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [revealed, setRevealed] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const generate = useServerFn(generateQuiz);
  const mutation = useMutation({
    mutationFn: () => generate({ data: { text, count, difficulty, sourceName } }),
    onSuccess: (data) => {
      setQuestions(data.questions);
      setAnswers({});
      setRevealed(false);
      toast.success(`${data.questions.length} questions generated`);
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const words = useMemo(() => text.trim().split(/\s+/).filter(Boolean).length, [text]);
  const score = useMemo(
    () => questions.filter((q, i) => answers[i] === q.correctIndex).length,
    [questions, answers],
  );
  const answered = Object.keys(answers).length;

  async function onFile(file: File | undefined) {
    if (!file) return;
    if (file.size > 2_000_000) {
      toast.error("File is larger than 2 MB.");
      return;
    }
    const content = await file.text();
    setText(content);
    setSourceName(file.name);
    toast.success(`Loaded ${file.name}`);
  }

  return (
    <div className="min-h-screen bg-background">
      <Toaster position="top-center" />
      <header className="border-b border-border/60 bg-card/40 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-6 py-5">
          <div className="flex items-center gap-3">
            <span className="grid size-10 place-items-center rounded-xl bg-primary text-primary-foreground">
              <Brain className="size-5" />
            </span>
            <div>
              <h1 className="text-lg font-semibold tracking-tight">QuizForge</h1>
              <p className="text-xs text-muted-foreground">
                AI assessment generator for uploaded documents
              </p>
            </div>
          </div>
          <Badge variant="secondary" className="hidden sm:inline-flex">
            <Sparkles className="mr-1 size-3" /> Powered by Lovable AI
          </Badge>
        </div>
      </header>

      <main className="mx-auto grid max-w-6xl gap-6 px-6 py-8 lg:grid-cols-[380px_1fr]">
        <section className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <FileText className="size-4" /> Source document
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <input
                ref={fileRef}
                type="file"
                accept=".txt,.md,.csv,.json,text/*"
                className="hidden"
                onChange={(e) => onFile(e.target.files?.[0])}
              />
              <Button
                variant="outline"
                className="w-full"
                onClick={() => fileRef.current?.click()}
              >
                <Upload className="size-4" /> Upload .txt / .md / .csv
              </Button>
              <div className="space-y-2">
                <Label htmlFor="doc">Or paste your content</Label>
                <Textarea
                  id="doc"
                  value={text}
                  onChange={(e) => {
                    setText(e.target.value);
                    setSourceName("");
                  }}
                  placeholder="Paste the training material, job description or study notes here…"
                  className="min-h-56 resize-y"
                />
                <p className="text-xs text-muted-foreground">
                  {sourceName ? `${sourceName} · ` : ""}
                  {words} words
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Target className="size-4" /> Generation settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label>Number of questions</Label>
                  <span className="text-sm font-medium">{count}</span>
                </div>
                <Slider
                  value={[count]}
                  min={1}
                  max={15}
                  step={1}
                  onValueChange={(v) => setCount(v[0] ?? 1)}
                />
              </div>
              <div className="space-y-3">
                <Label>Difficulty</Label>
                <div className="grid grid-cols-3 gap-2">
                  {DIFFICULTIES.map((d) => (
                    <Button
                      key={d}
                      size="sm"
                      variant={difficulty === d ? "default" : "outline"}
                      onClick={() => setDifficulty(d)}
                      className="capitalize"
                    >
                      {d}
                    </Button>
                  ))}
                </div>
              </div>
              <Button
                className="w-full"
                disabled={mutation.isPending || text.trim().length < 40}
                onClick={() => mutation.mutate()}
              >
                {mutation.isPending ? (
                  <>
                    <Loader2 className="size-4 animate-spin" /> Analysing document…
                  </>
                ) : (
                  <>
                    <Sparkles className="size-4" /> Generate MCQs
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </section>

        <section className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-3">
            <StatCard label="Questions" value={String(questions.length)} />
            <StatCard label="Answered" value={`${answered}/${questions.length || 0}`} />
            <StatCard
              label="Score"
              value={revealed ? `${score}/${questions.length}` : "—"}
            />
          </div>

          {questions.length > 0 && (
            <Progress value={questions.length ? (answered / questions.length) * 100 : 0} />
          )}

          {questions.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="flex flex-col items-center gap-3 py-20 text-center">
                <Brain className="size-10 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">
                  Upload or paste a document, then generate an assessment.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {questions.map((q, qi) => (
                <Card key={qi}>
                  <CardHeader>
                    <CardTitle className="text-base leading-relaxed">
                      <span className="mr-2 text-muted-foreground">Q{qi + 1}.</span>
                      {q.question}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {q.options.map((opt, oi) => {
                      const selected = answers[qi] === oi;
                      const correct = revealed && oi === q.correctIndex;
                      const wrong = revealed && selected && oi !== q.correctIndex;
                      return (
                        <button
                          key={oi}
                          onClick={() => !revealed && setAnswers((a) => ({ ...a, [qi]: oi }))}
                          className={[
                            "flex w-full items-center gap-3 rounded-lg border px-3 py-2.5 text-left text-sm transition-colors",
                            correct
                              ? "border-primary bg-primary/10"
                              : wrong
                                ? "border-destructive bg-destructive/10"
                                : selected
                                  ? "border-primary bg-accent"
                                  : "border-border hover:bg-accent",
                          ].join(" ")}
                        >
                          <span className="grid size-6 shrink-0 place-items-center rounded-md bg-muted text-xs font-medium">
                            {String.fromCharCode(65 + oi)}
                          </span>
                          <span className="flex-1">{opt}</span>
                          {correct && <CheckCircle2 className="size-4 text-primary" />}
                          {wrong && <XCircle className="size-4 text-destructive" />}
                        </button>
                      );
                    })}
                    {revealed && q.explanation && (
                      <p className="rounded-lg bg-muted p-3 text-xs text-muted-foreground">
                        {q.explanation}
                      </p>
                    )}
                  </CardContent>
                </Card>
              ))}

              <div className="flex flex-wrap gap-3 pb-10">
                <Button onClick={() => setRevealed(true)} disabled={revealed}>
                  <CheckCircle2 className="size-4" /> Reveal answer key
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setAnswers({});
                    setRevealed(false);
                  }}
                >
                  <RefreshCw className="size-4" /> Reset attempt
                </Button>
              </div>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: string }) {
  return (
    <Card>
      <CardContent className="py-5">
        <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
        <p className="mt-1 text-2xl font-semibold tabular-nums">{value}</p>
      </CardContent>
    </Card>
  );
}
